@echo off
cd /d "%~dp0"
echo Lancement de l'editeur isometrique...
start http://localhost:8080/DnDCarte9.html
civetweb.exe -document_root . -listening_port 8080